import * as FlexPlugin from 'flex-plugin';
import SamplePlugin from './SamplePlugin';
import AddCustomViewPlugin from './AddCustomViewPlugin';
import ActionsPlugin from './ActionsPlugin';

FlexPlugin.loadPlugin(SamplePlugin);
FlexPlugin.loadPlugin(AddCustomViewPlugin);