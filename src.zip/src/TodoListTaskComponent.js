import React from 'react';

const TodoListComponent =()=>
<div>
    <br />
    <hr />
    <h1> TO DO</h1>
    <ul>
        <li> Answer the task</li>
        <li> Answer the task</li>
        <li> Answer the task</li>
        <li> Answer the task</li>

        <li> Answer the task</li>
        <li> Answer the task</li>
  </ul>
</div>